import numpy as np
import matplotlib.pyplot as plt
#import math

# load data from class out files of transfer functions 
z1,H1,I1,J1,K1,L1= np.loadtxt("planck_s8_nt_z1_tk.dat", unpack=True,usecols = [0,2,3,5,6,7])
z2,H2,I2,J2,K2,L2= np.loadtxt("planck_s8_nt_z2_tk.dat", unpack=True,usecols = [0,2,3,5,6,7])
#z3,H3,I3,J3,K3,L3 = np.loadtxt("New4neV_z1_tk.dat", unpack=True,usecols = [0,3])
#z4,H4,I4,J4,K4,L4 = np.loadtxt("New4neV_z2_tk.dat", unpack=True,usecols = [0,3])


# taking log of transfer functions
p1=(np.log(-H1))
p2=(np.log(-H2))
p3=(np.log(-I1))
p4=(np.log(-I2))
p5=(np.log(-J1))
p6=(np.log(-J2))
p7=(np.log(-K1))
p8=(np.log(-K2))
p9=(np.log(-L1))
p10=(np.log(-L2))


#to get the difference 

dH=(p1-p2)*49.1988966026
dH1=(p3-p4)*49.1988966026
dH2=(p5-p6)*49.1988966026
dH3=(p7-p8)*49.1988966026
dH4=(p9-p10)*49.623025

#dH1=(p3-p4)*21.854345


data = np.column_stack((z1, dH,dH1,dH2,dH3,dH4))
header = "k ,   growth_baryon , growth_cdm, growth_ncdm0,growth_ncdm_1, growth_tot"
np.savetxt('growth_nonthermal.dat', data,header=header)
#plt.xticks([1,1.05,1.1])
#plt.plot(z1,H1)
#plt.plot(z2,H2)
plt.loglog(z1,dH,label='baryon')
plt.loglog(z1,dH1,label='cdm')
#plt.loglog(z1,dH2,label='m_ncdm__0')
plt.loglog(z1,dH3,label='m_ncdm__1')
plt.loglog(z1,dH4,label='total')
#print dH[4296]
#print dH[5285]
#plt.yticks(np.arange(1,2,0.1))
#plt.xticks(np.arange(0, 1, 0.1))
#plt.ylim(-1,2.2)
#plt.xlim(-0.05,10)
plt.legend()

plt.xlabel('k',fontsize=14)
plt.ylabel('growth factor', fontsize=14)
plt.title('scale dependent growth factor')

#plt.yscale('log')
plt.show()
#print d22-d22[0]
